import React, { useState, useEffect } from 'react';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';

export default function BuildingProgressSketch() {
  const [floors, setFloors] = useState(30);
  const [aptsPerFloor, setAptsPerFloor] = useState(50);
  const defaultStages = [
    'Wall Foundations',
    'Contract Signing',
    'Install Electrical Boxes & Conduits',
    'Cable Pulling (Wiring)',
    'Open Boxes After Plaster',
    'Main Power Cable Pull',
    'Main Communications Cable Pull',
    'Install Electrical Accessories',
    'Install Circuit Breakers',
    'Prepare for Inspection & Circuit Mapping',
    'Electric Company Inspection',
    'Handover Apartment'
  ];
  const [stages, setStages] = useState(defaultStages);
  const [building, setBuilding] = useState([]);
  const [selected, setSelected] = useState(null);
  const [filterIncompleteOnly, setFilterIncompleteOnly] = useState(false);

  const makeApt = (floorIndex, aptIndex) => ({
    id: `${floorIndex + 1}-${aptIndex + 1}`,
    floor: floorIndex + 1,
    apt: aptIndex + 1,
    stages: stages.map(() => false),
    note: ''
  });

  useEffect(() => {
    const savedKey = `building_${floors}x${aptsPerFloor}_${stages.length}`;
    const saved = localStorage.getItem(savedKey);
    if (saved) {
      try { setBuilding(JSON.parse(saved)); return; } catch(e){/* ignore */ }
    }
    const b = [];
    for (let f = 0; f < floors; f++) {
      const row = [];
      for (let a = 0; a < aptsPerFloor; a++) row.push(makeApt(f,a));
      b.push(row);
    }
    setBuilding(b);
  }, [floors, aptsPerFloor, stages.length]);

  useEffect(() => {
    const key = `building_${floors}x${aptsPerFloor}_${stages.length}`;
    try { localStorage.setItem(key, JSON.stringify(building)); } catch(e){}
  }, [building, floors, aptsPerFloor, stages.length]);

  const toggleStage = (floorIndex, aptIndex, stageIndex) => {
    setBuilding(prev => {
      const copy = prev.map(r => r.map(a => ({ ...a, stages: [...a.stages] })));
      copy[floorIndex][aptIndex].stages[stageIndex] = !copy[floorIndex][aptIndex].stages[stageIndex];
      return copy;
    });
  };

  const setAllStageForApt = (floorIndex, aptIndex, value) => {
    setBuilding(prev => {
      const copy = prev.map(r => r.map(a => ({ ...a, stages: [...a.stages] })));
      copy[floorIndex][aptIndex].stages = copy[floorIndex][aptIndex].stages.map(() => value);
      return copy;
    });
  };

  const setBulkStageForFloor = (floorIndex, stageIndex, value) => {
    setBuilding(prev => {
      const copy = prev.map(r => r.map(a => ({ ...a, stages: [...a.stages] })));
      for (let i = 0; i < copy[floorIndex].length; i++) copy[floorIndex][i].stages[stageIndex] = value;
      return copy;
    });
  };

  const completionPercent = apt => {
    const done = apt.stages.filter(Boolean).length;
    return Math.round((done / stages.length) * 100);
  };

  const exportJSON = () => {
    const data = { generatedAt: new Date().toISOString(), floors, aptsPerFloor, stages, building };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    saveAs(blob, `building_${floors}x${aptsPerFloor}_${new Date().toISOString()}.json`);
  };

  const exportExcel = () => {
    // build rows for each apartment with stage statuses
    const rows = [];
    for (let f = 0; f < building.length; f++) {
      for (let a = 0; a < building[f].length; a++) {
        const apt = building[f][a];
        const row = {
          Floor: apt.floor,
          Apartment: apt.apt,
          ID: apt.id,
          CompletionPercent: completionPercent(apt),
          Note: apt.note
        };
        stages.forEach((s, si) => row[s] = apt.stages[si] ? 'Done' : 'Pending');
        rows.push(row);
      }
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'BuildingReport');
    const wbout = XLSX.write(wb, { bookType:'xlsx', type:'array' });
    saveAs(new Blob([wbout],{type:'application/octet-stream'}), `building_report_${new Date().toISOString().slice(0,19)}.xlsx`);
  };

  const exportPDF = () => {
    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    doc.setFontSize(14);
    doc.text(`Building Report — ${floors} floors x ${aptsPerFloor} apts`, 40, 40);
    let y = 70;
    // Add table-like output; paginate if needed
    for (let f = 0; f < building.length; f++) {
      for (let a = 0; a < building[f].length; a++) {
        const apt = building[f][a];
        const line = `Floor ${apt.floor} Apt ${apt.apt} — ${completionPercent(apt)}%`;
        doc.text(line, 40, y);
        y += 16;
        // stages list (short)
        const stageLine = stages.map((s,si) => `${si+1}.${apt.stages[si] ? '✓' : '✗'}`).join(' ');
        doc.setFontSize(9);
        doc.text(stageLine, 50, y, { maxWidth: 500 });
        y += 28;
        doc.setFontSize(14);
        if (y > 700) {
          doc.addPage();
          y = 40;
        }
      }
    }
    doc.save(`building_report_${new Date().toISOString().slice(0,19)}.pdf`);
  };

  const resetProgress = () => {
    if (!window.confirm('Reset all progress for current building?')) return;
    setBuilding(prev => prev.map(row => row.map(apt => ({ ...apt, stages: stages.map(()=>false), note: '' }))));
  };

  const filteredBuilding = filterIncompleteOnly
    ? building.map(row => row.filter(apt => completionPercent(apt) < 100))
    : building;

  return (
    <div className="p-4 min-h-screen">
      <header className="mb-4">
        <h1 className="text-2xl font-semibold">Building Progress Sketch</h1>
        <p className="text-sm text-gray-600">Set floors/apartments, click any apartment to edit stages and notes.</p>
      </header>

      <section className="mb-4 grid gap-3 grid-cols-1 md:grid-cols-3">
        <div className="p-3 bg-white rounded-2xl shadow-sm">
          <label className="block text-sm">Floors</label>
          <input type="number" value={floors} min={1} max={200} onChange={(e)=>setFloors(Number(e.target.value))} className="w-full mt-2 p-2 border rounded" />

          <label className="block text-sm mt-3">Apartments per floor</label>
          <input type="number" value={aptsPerFloor} min={1} max={200} onChange={(e)=>setAptsPerFloor(Number(e.target.value))} className="w-full mt-2 p-2 border rounded" />

          <label className="block text-sm mt-3">Stages (comma separated)</label>
          <input value={stages.join(', ')} onChange={(e)=>setStages(e.target.value.split(',').map(s=>s.trim()).filter(Boolean))} className="w-full mt-2 p-2 border rounded" />

          <div className="flex gap-2 mt-3">
            <button className="px-3 py-2 rounded bg-indigo-600 text-white" onClick={exportJSON}>Export JSON</button>
            <button className="px-3 py-2 rounded border" onClick={resetProgress}>Reset Progress</button>
          </div>

          <div className="mt-3 flex gap-2">
            <button className="px-3 py-2 rounded bg-green-600 text-white" onClick={exportExcel}>Export Excel</button>
            <button className="px-3 py-2 rounded bg-red-600 text-white" onClick={exportPDF}>Export PDF</button>
          </div>
        </div>

        <div className="p-3 bg-white rounded-2xl shadow-sm col-span-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2"><input type="checkbox" checked={filterIncompleteOnly} onChange={(e)=>setFilterIncompleteOnly(e.target.checked)} /> Show incomplete only</label>
            </div>
            <div className="text-sm text-gray-600">Stages: {stages.length} — Apartments: {floors * aptsPerFloor}</div>
          </div>

          <div className="mt-3 overflow-auto p-2 border rounded h-[60vh] bg-white">
            <div className="flex flex-col gap-4">
              {filteredBuilding.slice().reverse().map((row, rIndex) => {
                const floorIndex = floors - 1 - rIndex;
                return (
                  <div key={floorIndex} className="border rounded p-2">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">Floor {floorIndex + 1}</div>
                      <div className="flex items-center gap-2">
                        {stages.map((s, si) => (
                          <button key={si} className="text-xs px-2 py-1 border rounded" onClick={()=>setBulkStageForFloor(floorIndex, si, true)} title={`Set all ${s} done on floor ${floorIndex + 1}`}>
                            ✓ {si + 1}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
                      {row.map((apt, aIndex) => {
                        const aptFloorIndex = floorIndex;
                        const aptIndex = aIndex;
                        const percent = completionPercent(apt);
                        const color = percent === 100 ? 'bg-green-100 border-green-400' : percent >= 50 ? 'bg-yellow-50 border-yellow-300' : 'bg-red-50 border-red-300';
                        return (
                          <div key={apt.id} className={`p-2 border rounded ${color} cursor-pointer`} onClick={()=>setSelected({ floorIndex: aptFloorIndex, aptIndex })}>
                            <div className="text-xs font-medium">Apt {apt.apt}</div>
                            <div className="text-2xs text-gray-600">{apt.id}</div>
                            <div className="mt-2 text-sm">{percent}%</div>
                            <div className="h-2 bg-gray-200 rounded mt-2 overflow-hidden">
                              <div style={{ width: `${percent}%` }} className="h-full bg-indigo-500" />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {selected && (
        <div className="fixed inset-0 bg-black/40 flex items-end md:items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full md:w-2/3 p-4 max-h-[90vh] overflow-auto">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Apartment {building[selected.floorIndex][selected.aptIndex].apt} — Floor {building[selected.floorIndex][selected.aptIndex].floor}</h2>
              <div className="flex gap-2">
                <button className="px-3 py-1 border rounded" onClick={()=>setAllStageForApt(selected.floorIndex, selected.aptIndex, true)}>Mark all done</button>
                <button className="px-3 py-1 border rounded" onClick={()=>setAllStageForApt(selected.floorIndex, selected.aptIndex, false)}>Clear all</button>
                <button className="px-3 py-1 rounded bg-gray-100" onClick={()=>setSelected(null)}>Close</button>
              </div>
            </div>

            <div className="mt-4 grid gap-3">
              {stages.map((s, si) => (
                <label key={si} className="flex items-center gap-3 p-2 border rounded">
                  <input type="checkbox" checked={building[selected.floorIndex][selected.aptIndex].stages[si]} onChange={()=>toggleStage(selected.floorIndex, selected.aptIndex, si)} />
                  <div>
                    <div className="font-medium">{s}</div>
                    <div className="text-sm text-gray-500">Stage {si+1} of {stages.length}</div>
                  </div>
                </label>
              ))}

              <div>
                <label className="block text-sm">Note</label>
                <textarea value={building[selected.floorIndex][selected.aptIndex].note} onChange={(e)=> {
                  const val = e.target.value;
                  setBuilding(prev=>{
                    const copy = prev.map((r)=> r.map((a)=> ({ ...a, stages: [...a.stages] })));
                    copy[selected.floorIndex][selected.aptIndex].note = val;
                    return copy;
                  });
                }} className="w-full p-2 border rounded mt-1" />
              </div>

              <div className="flex gap-2">
                <button className="px-3 py-2 rounded bg-indigo-600 text-white" onClick={()=>{ setSelected(null); }}>Save & Close</button>
                <button className="px-3 py-2 rounded border" onClick={()=>setSelected(null)}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="mt-6 text-sm text-gray-600">Tip: Click the stage buttons at the top of each floor to mark that stage done for the whole floor.</footer>
    </div>
  );
}
