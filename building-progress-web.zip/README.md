# Building Progress - Ready Web App

This is a ready-to-deploy React + Tailwind web app to track progress of apartments in a multi-floor building.
Features:
- Configure floors and apartments per floor.
- Per-apartment checklist with the electrical stages you requested.
- Export full detail reports as **Excel** (.xlsx) and **PDF**.
- Export raw JSON and localStorage persistence.
- Ready to deploy on Netlify / Vercel.

## How to use locally

1. Install dependencies:
```bash
npm install
```

2. Start dev server:
```bash
npm start
```

3. Build for production:
```bash
npm run build
```

## Deploy
- You can directly connect this repository to Netlify or Vercel. The build command is `npm run build` and the publish directory is `build/`.

## Notes
- PDF generation uses `jspdf` and may paginate long reports.
- Excel uses `xlsx` and `file-saver`.
